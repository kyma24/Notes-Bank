def getRootVal(root):
    return root[0]
    
def setRootVal(root,newVal):
    root[0] = newVal
    
def getLeftChild(root):
    return root[1]
    
def getRightChild(root):
    return root[2]
