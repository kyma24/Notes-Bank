def BinaryTree(r):
    return [r, [], []]    
