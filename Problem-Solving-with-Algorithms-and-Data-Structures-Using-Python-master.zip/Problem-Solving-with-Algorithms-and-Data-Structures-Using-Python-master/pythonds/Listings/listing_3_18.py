def isEmpty(self):
    return self.head == None
