'''
	A very simple example of a binary tree created on a 
	python list primitive data structure
'''
myTree = ['a',['b',['d',[],[]],['e',[],[]]],['c',['f',[],[]],[]] ]
print(myTree)
print('left subtree = ', myTree[1])
print('root = ', myTree[0])
print('right subtree = ', myTree[2])
