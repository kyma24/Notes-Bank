
def listsum(numList):
    theSum = 0
    for i in numList:
        theSum = theSum + i
    return theSum

def main():
    print(listsum([1,3,5,7,9]))


if __name__ == "__main__":
    main()
