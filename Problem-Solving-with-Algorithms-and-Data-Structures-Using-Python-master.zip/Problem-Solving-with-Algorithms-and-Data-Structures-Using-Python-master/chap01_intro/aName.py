
aName = input('Please enter your name: ')
print("Your name in all capitals is", aName.upper(), "and has length", len(aName))
