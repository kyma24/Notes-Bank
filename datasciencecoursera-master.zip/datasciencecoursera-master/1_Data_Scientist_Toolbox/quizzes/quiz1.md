# The Data Scientist's Toolbox Quiz 1 (JHU) Coursera

Question 1
----------
Which of the following are courses in the Data Science Specialization? Select all that apply:

* Business Analytics
* Python Programming
* Developing Data Products (previously known as Building Data Products)
* R programming

Answers: </br>
Developing Data Products (previously known as Building Data Products) </br>
R programming

Question 2
----------
Why are we using R for the course track? Select all that apply.

* R has a nice IDE, Rstudio
* Packages are easy to install and "play nicely" together
* R allows object oriented programming
* R is the best cloud computing language

Answers: </br>
R has a nice IDE, Rstudio </br>
Packages are easy to install and "play nicely" together

Question 3
----------
What are good ways to find answers to questions in this course track? Select all that apply.

* Looking through R help files
* Expecting every answer to be in a lecture slide
* Asking a skilled friend
* Posting homework assignments to mailing lists

Answers: </br>
Looking through R help files </br>
Asking a skilled friend

Question 4
----------
What are characteristics of good questions on the message boards? Select all that apply.

* Is an exact homework question
* Is polite and courteous
* Explicitly lists versions of software being used
* Provides no details

Answers: </br>
Is polite and courteous </br>
Explicitly lists versions of software being used

Question 5
----------
Which of the following packages provides machine learning functionality? Select all that apply

* knitr
* cacheSweave
* gbm
* pamr

Answers: </br>
gbm </br> 
pamr </br> 
