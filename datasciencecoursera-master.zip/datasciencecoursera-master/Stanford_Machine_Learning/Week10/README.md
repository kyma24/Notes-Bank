# Andrew Ng's Machine Learning course implemented in Python
Author: Michael Galarnyk <br />

## Project 
Markdown | R Markdown
--- | ---
Coming soon| Coming soon

## Quizzes
Quiz # | Link 
--- | --- 
4 | Coming soon
3 | [Quiz](https://github.com/mGalarnyk/datasciencecoursera/blob/master/6_%20Statistical_Inference/quizzes/quiz3withExplanation.md)
2 | [Quiz](https://github.com/mGalarnyk/datasciencecoursera/blob/master/6_%20Statistical_Inference/quizzes/quiz2withExplanation.md)
1 | [Quiz](https://github.com/mGalarnyk/datasciencecoursera/blob/master/6_%20Statistical_Inference/quizzes/quiz1withExplanation.md)

## Contributors
FirstName | LastName | Email
--- | --- | ---
Michael |  Galarnyk |  <mgalarny@gmail.com>
Submit |  Pull Request | <youremailhere@gmail.com>

## License
Anyone may contribute 
