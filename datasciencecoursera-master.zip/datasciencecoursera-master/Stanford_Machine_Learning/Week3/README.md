# Andrew Ng's Machine Learning course implemented in Python
Author: Michael Galarnyk <br />

## Contributors
FirstName | LastName | Email
--- | --- | ---
Michael |  Galarnyk |  <mgalarny@gmail.com>
Saurav | Chaudhary | <sauravchaudhary717@gmail.com>
Submit |  Pull Request | <youremailhere@gmail.com>

## License
Anyone may contribute 
