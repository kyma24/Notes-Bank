#!/usr/bin/env python

import numpy as np

def warmUpExercise(*args, **kwargs):

# warmUpExercise Example function in python
#   warmUpExercise() is an example function that returns the 5x5 identity matrix

# ============= YOUR CODE HERE ==============
# Instructions: Return the 5x5 identity matrix 
#               In python, we return values by defining which variables
#               represent the return values (at the top of the file)
#               and then set them accordingly. 


    return np.identity(5)


# ===========================================

