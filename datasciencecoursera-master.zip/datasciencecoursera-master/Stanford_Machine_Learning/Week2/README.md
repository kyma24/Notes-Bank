# Andrew Ng's Machine Learning course implemented in Python
Author: Michael Galarnyk <br />
